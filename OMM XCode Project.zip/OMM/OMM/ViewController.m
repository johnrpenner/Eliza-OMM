//  ViewController.m
//  OMM 0.4.0
//	Updated: August 15, 2015
//  Created by John Penner on 07-05-15.
//  Copyright (c) 2015 John Penner. All rights reserved.

#import "ViewController.h"

#import <AVFoundation/AVFoundation.h>
#import "QuartzCore/CAAnimation.h"
#import <AudioToolbox/AudioToolbox.h>


@interface ViewController ()

@end


@implementation ViewController

// OFFSET INDICES FOR REPLY STARTS
//NSArray *SS = [[NSArray alloc] initWithObjects: @[ @(1), @(4), @(6), @(6), @(10), @(14), @(17), @(20), @(22), @(25), @(28), @(28), @(32), @(35), @(40), @(40), @(40), @(40), @(40), @(40), @(49), @(51), @(55), @(59), @(63), @(63), @(64), @(69), @(74), @(76), @(80), @(83), @(90), @(93), @(99), @(106) ], nil];
NSInteger SS[36] = {1, 4, 6, 6, 10, 14, 17, 20, 22, 25, 28, 28, 32, 35, 40, 40, 40, 40, 40, 40, 49, 51, 55, 59, 63, 63, 64, 69, 74, 76, 80, 83, 90, 93, 99, 106};

// REPLY IN USE DEFAULTS TO FIRST OFFSET INDEX
NSInteger RR[36] = {1, 4, 6, 6, 10, 14, 17, 20, 22, 25, 28, 28, 32, 35, 40, 40, 40, 40, 40, 40, 49, 51, 55, 59, 63, 63, 64, 69, 74, 76, 80, 83, 90, 93, 99, 106};

// NUM REPLIES PER OFFSET INDEX
NSInteger NN[36] = {3, 5, 9, 9, 13, 16, 19, 21, 24, 27, 31, 31, 34, 39, 48, 48, 48, 48, 48, 48, 50, 54, 58, 62, 63, 63, 68, 73, 75, 79, 82, 89, 92, 98, 105, 112};


@synthesize textResponse;
@synthesize textOutput;
@synthesize textInput;

@synthesize inputStr;		// I$ Input String
@synthesize keywordStr;		// K$ Keyword String
@synthesize conjugatedStr;	// C$ Conjugated or Translated string

@synthesize Fstr;			// F$ Reply String (also used to save K$ in scanning for keyword)
@synthesize Rstr;			// R$ Used in conjugation process
@synthesize Sstr;			// S$ Used in conjugation process
@synthesize prevInput;			// P$ Previous input string
@synthesize Zstr;			// Z$ Scratch (used for simulating RESTORE NNNN)

@synthesize K;				// K   Keyword Number
@synthesize Sint, T;		// S,T Used to save K and L when scanning for Keyword
//@synthesize X, L;			// X,L Scratch where X loops and L scans through Strings
@synthesize V;				// V   Used for scanning for keyword string
	
@synthesize N1;				// Number of Keywords
@synthesize N2;				// Number of Conjugations (i.e. translations)
@synthesize N3;				// Number of Replies

//@synthesize S;				// Ordinal to start of replies for a given keyword
//@synthesize RR;				// Reply[current]
//@synthesize N;				// Ordinal to last reply for a given keyword


- (void)viewDidLoad {

	[super viewDidLoad];

	// Setup
	self.view.backgroundColor = [UIColor grayColor];
	[UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;

	// SELF > uiLayerView:219
	UIImage *frameImage = [UIImage imageNamed:@"noBoard.png"];
	UIImageView *uiLayerView = [[UIImageView alloc] initWithImage:frameImage];
	[uiLayerView setTag:219];
	
	// SELF > frameImage:220
	UIImageView *frameImageView = [[UIImageView alloc] initWithImage:frameImage];
	[frameImageView setTag:220];

	// SELF > backgroundImage:221
	UIImage *backgroundImage = [UIImage imageNamed:@"memlingChrist.png"];
	UIImageView *backgroundImageView = [[UIImageView alloc] initWithImage:backgroundImage];
	[backgroundImageView setTag:221];
	
	// SELF.VIEW > frameImage & backgroundImage
	[self.view addSubview:frameImageView];
	[self.view addSubview:uiLayerView];
	[self.view addSubview:backgroundImageView];
	
	// background image covers up the NIB!! move behind NIB
	[self.view sendSubviewToBack:backgroundImageView];
	
	textResponse.textColor = [UIColor whiteColor];
	textResponse.alpha = 0.8;
	[uiLayerView addSubview:textResponse];
	
	textOutput.alpha = 0.8;
	[uiLayerView addSubview:textOutput];
	
	textInput.textColor = [UIColor whiteColor];
	textInput.alpha = 0.8;
	//[textInput setTag:123];
	textInput.tag = 123;
	[uiLayerView addSubview:textInput];
	[textInput becomeFirstResponder];
	
	[self initEliza];
	
}


- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent*)event
{
	[super touchesEnded: touches withEvent: event];

	UITouch *theTouch = [touches anyObject];
	CGPoint endPoint = [theTouch locationInView:self.view];

	CGFloat X = endPoint.x;
	CGFloat Y = endPoint.y;
	
	//textOutput.text = [NSString stringWithFormat:@"X: %3f • Y:%3f", X, Y];
	
	if ((Y>300) && (Y<700)) [(UITextField *)[self.view viewWithTag:123] becomeFirstResponder];
	if ((Y<300) || (Y>700)) [(UITextField *)[self.view viewWithTag:123] resignFirstResponder];
	
	if ((Y>300) && (Y<700) && (X<100)) [(UITextField *)[self.view viewWithTag:123] setText:@""];

	return;
}


//Asks the delegate if editing should begin in the specified text field.
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	return YES;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
	return YES;
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	if (textField.tag == 123) {
		[textField resignFirstResponder];
		[self fwootch];
		return YES;
		}

	return NO;
}


- (void) fwootch
{
	[self playSound:1];
	NSString* inText = [(UITextField *)[self.view viewWithTag:123] text];
	textOutput.text = inText;
	textInput.text = @"";
	NSLog([NSString stringWithFormat:@"User: %@", inText]);
	
	NSString *elizaSez = [self eliza:inText];
	textResponse.text = elizaSez;
	[self speak:elizaSez];
	
	[(UITextField *)[self.view viewWithTag:123] becomeFirstResponder];
	
	return;
}


/*------------------------------------------------------------------------------
	ELIZA for iOS by John Roland Penner 2015
	BASIC version by Jeff Shrager 1973; published Creative Computing 1977
	Original LISP version by Joseph Weizenbaum and Bernie Cosell, MIT 1966
	
	THX-1138::OMM 0910: Hans Memling Christ Giving His Blessing (1478)
	Hi! I'm Eliza. What is your problem?
	What's wrong? My time is yours. Proceed.
	Yes, I understand. Excellent. Could you be more specific?
	You are a true believer, blessings of the State, blessings of the masses.
	Work hard, increase production, prevent accidents and be happy.
------------------------------------------------------------------------------*/


- (void) initEliza
{
	inputStr = @"";			// I$ Input String
	keywordStr = @"";		// K$ Keyword String
	conjugatedStr = @"";	// C$ Conjugated or Translated string
 
	Fstr = @"";				// F$ Reply String (also used to save K$ in scanning for keyword)
	Rstr = @"";				// R$ Used in conjugation process
	Sstr = @"";				// S$ Used in conjugation process
	prevInput = @"";		// P$ Previous input string
	Zstr = @"";				// Z$ Scratch (used for simulating RESTORE NNNN)
	
	K = 0;					// K   Keyword Number
	Sint = 0; T = 0;		// S,T Used to save K and L when scanning for Keyword
	//X = 0; L = 0;			// X,L Scratch where X loops and L scans through Strings
	V = 0;					// V   Used for scanning for keyword string
	
	N1 = 36;				// Number of Keywords
	//N2 = 12;				// Number of Conjugations (i.e. translations)
	N2 = 28;				// Number of Conjugations (i.e. translations)
	N3 = 112;				// Number of Replies
	
	return;
}


- (NSString *) eliza:(NSString*) inputText
{
	NSString *returnStr = @"";
	NSString *scrubbedText = [self scrubInput: inputText];
	
	// no repeats
	if (scrubbedText == prevInput) returnStr = @"Please dont repeat yourself! ";

	prevInput = scrubbedText;
	inputStr = scrubbedText;
	
	// down the rabbit hole..
	returnStr = [self findKeyword:inputStr];
	NSLog(@"Eliza: %@", returnStr);
	
	return returnStr;
}


- (NSString*) scrubInput:(NSString*) inStr
{
	NSString *returnStr = @"";
	
	// prefix + suffix one space
	inStr = [NSString stringWithFormat:@"%@%@%@", @" ", inStr, @" "];
	
	// remove quotation marks (so DONT and DON'T are equivalent)
	NSString *stripString = [inStr stringByReplacingOccurrencesOfString:@"\"" withString:@""];
	stripString = [stripString stringByReplacingOccurrencesOfString:@"\'" withString:@""];
	returnStr = stripString;
	
	// return "QUIT"
	NSArray *words = [stripString componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	if ( [words indexOfObject:@"SHUTUP"] != NSNotFound ||
		[words indexOfObject:@"QUIT"] != NSNotFound ||
		[words indexOfObject:@"EXIT"] != NSNotFound ||
		[words indexOfObject:@"BYE"] != NSNotFound ) returnStr = @"QUIT";
	
	return returnStr;
}


/* --- FIND KEYWORD ------------------------------------------------------------

	RESTORE : S=0
	
	// K = keyword index
	FOR K = 1 TO N1
		READ K$							// [keywords objectAtIndex:K]
		IF S > 0 THEN 390  //next k
	
 		// S and T and F$
		FOR L = 1 TO LEN(I$) - LEN(K$)+1 {
			IF MID$( I$, L, LEN(K$) ) = K$ {
				S = K
				T = L
				F$ = K$
				}
			} //NEXT L
		} //NEXT K
	
	// S and T and F$
	IF S > 0 {
		K = S
		L = T
		GOTO 430  // conjugate
		}
	
	// NOKEYFOUND > say something non-commital
	K = 36 : GOTO 630  //getReply

------------------------------------------------------------------------------*/


- (NSString *) findKeyword:(NSString*) inStr
{
	// KEYWORDS (with blank 0th element)
	NSArray *keywords = [NSArray arrayWithObjects: @"",
		@"can you", @"can I", @"you are", @"youre", @"I dont",
		@"I feel", @"why dont you", @"why cant I", @"are you", @"I cant",
		@"I am", @"Im ", @"you ", @"I want", @"what",
		@"how", @"who", @"where", @"when", @"why",
		@"name", @"cause", @"sorry", @"dream", @"hello",
		@"hi", @"maybe", @"no ", @"your", @"always",
		@"think", @"alike", @"yes", @"friend", @"computer",
		@"NOKEYFOUND", nil];
	
	NSUInteger kk;
	NSUInteger ss = 0;
	NSUInteger tt = 0;
	NSString *FStr;

	NSInteger ll;
	NSString *conjugationStr = @"";
	NSString *replyStr = @"";
	NSString *endStr;
	
	// scan for keywords > save keyword of highest priority to S, T, and F$
	for (kk = 0; kk < N1; kk++) {
		NSRange range = [inStr rangeOfString:keywords[kk]];
		if ( range.location != NSNotFound ) {
			ss = kk;				//ss=found keyword index [1-35..36]
			tt = range.location;	//tt=ll range.location
			FStr = keywords[kk];	//found keyword
			break;
			}
		}
	NSLog(@"Keyword: %@ ss:%d tt:%d ", FStr, ss, tt);
	
	
	// KEYWORD FOUND; Conjugate and Get Reply.
	if (ss>0) {
		kk = ss;
		ll = tt;
		conjugationStr = [self conjugate:inStr withKeyword:FStr withKK:kk andLL:ll];
		replyStr = [self getReply:FStr keywordIndex:kk keywordLoc:ll];
		
		// suffix the conjugation [WORKS!]
		NSRange starBlank = [replyStr rangeOfString:@"*"];
		if (starBlank.location != NSNotFound) {
			replyStr = [replyStr substringWithRange:NSMakeRange(0, replyStr.length-1)];
			replyStr = [NSString stringWithFormat:@"%@ %@", replyStr, conjugationStr];
			//previousInput = replyStr;
			}
		
		else {
			//previousInput = replyStr;
			}
		
		}
	
	// KEYWORD NOT FOUND; use kk=36 [NOKEYWORDFOUND], and Get Generic Reply.
	else {
		kk = 36;
		replyStr = [self getReply:Fstr keywordIndex:kk keywordLoc:tt];
		
		// suffix the conjugation [TAKE2]
		NSRange starBlank = [replyStr rangeOfString:@"*"];
		if (starBlank.location != NSNotFound) {
			replyStr = [replyStr substringWithRange:NSMakeRange(0, replyStr.length-1)];
			replyStr = [NSString stringWithFormat:@"%@ %@", replyStr, conjugationStr];
			//previousInput = replyStr;
			}
		
		else {
			//previousInput = replyStr;
			}
		}
	
	return replyStr;
}


//                                                                        KK=keywordIndex     LL=keywordLoc
- (NSString *) conjugate:(NSString*)inStr withKeyword:(NSString*)FStr withKK:(NSInteger)kk andLL:(NSInteger)ll
{
	// ORIGINAL 12 CONJUGATES
	//NSArray *sConjugate = [NSArray arrayWithObjects: @" are ", @" were ", @" you ", @" your ", @" Ive ", @" Im ", nil];
	//NSArray *rConjugate = [NSArray arrayWithObjects: @" am ", @" was ", @" I ", @" my ", @" youve ", @" youre ", nil];
	
	// NEW 28 CONJUGATES
	NSArray *sConjugate = [NSArray arrayWithObjects: @" are ", @" am ", @" were ", @" was ", @" you ", @" I ", @" your ", @" my" , @" Ive ", @" youve ", @" Im ", @" youre ", @" me ", @" you ", nil];
	NSArray *rConjugate = [NSArray arrayWithObjects: @" am ", @" are ", @" was ", @" were ", @" me ", @" you ", @" my ", @" your ", @" youve ", @" Ive ", @" youre ", @" Im ", @" you ", @" me ", nil];
	
	NSString *CStr;
	NSString *SStr;
	NSString *RStr;
	NSInteger iLen = [inStr length];
	NSInteger fLen = [FStr length];
	NSInteger rightStart = ll + fLen;  // iLen - fLen - ll+1; (doesnt work cause we index from LEFT)
	NSInteger rightEnd = iLen - rightStart;
	NSString *midS = @"";
	NSString *midR = @"";
	NSString *cLeft;
	NSString *cRight;
	NSInteger SLoc;
	
	//C$ = "" + RIGHT$( I$, LEN(I$) - LEN(F$) - L+1 )
	CStr = [inStr substringWithRange:NSMakeRange(rightStart, rightEnd)];
	NSLog([NSString stringWithFormat:@"CStr (%d..%d in %d): %@", rightStart, rightEnd, iLen, CStr]);
	
	// run through all the pairs of Conjugates
	for (NSInteger xx = 0; xx<(N2/2); xx++) {
		SStr = [sConjugate objectAtIndex:xx];
		RStr = [rConjugate objectAtIndex:xx];
		NSLog(@"--SStr[%d]: %@ | RStr[%d]: %@", xx, SStr, xx, RStr);
		
		// scan CStr and extract conjuagate prefix and suffix
		//for (NSInteger L = 0; L < CStr.length; L++) {
		NSRange range = [CStr rangeOfString:SStr];
		if ( range.location != NSNotFound ) {
			
			SLoc = range.location;
			NSLog(@"  SLoc: %d | SLen: %d | CLen: %d", SLoc, SStr.length, CStr.length);
			
			// grab the conjugate prefix
			if (SLoc + SStr.length <= CStr.length) {
				midS = [CStr substringWithRange:NSMakeRange(0, SLoc)];
				}
			
			// grab the conjugate suffix
			if (SLoc + SStr.length <= CStr.length) {
				midR = [CStr substringWithRange:NSMakeRange(SLoc + SStr.length, CStr.length - (SLoc+SStr.length) )];
				}
			
			CStr = [NSString stringWithFormat:@"%@%@%@", midS, RStr, midR];
			NSLog(@"Conjugate pieces: %@ | %@ > %@ | %@", midS, SStr, RStr, midR);
			
			break;
			}
		
		}  //next X
	
	return CStr;
}



/* -- CONJUGATION and TRANSLATION ----------------------------------------------

// take right part of string and conjugate correctly
// token after a keyword is saved
// pairs of translation strings are read
// upon occurence of a translation string other word-pair is substituted
// ensure there is only one leading space in translated string

	
	RESTORE : FOR X = 1 TO N1 : READ Z$ : NEXT X
	
	C$ = "" + RIGHT$( I$, LEN(I$) - LEN(F$) - L+1 )
	
	FOR X = 1 TO N2/2 {
		READ S$, R$								// [conjugateS objectAtIndex:X]
												// [conjugateR objectAtIndex:X]
 
		FOR L = 1 TO LEN(C$)
			IF L+LEN(S$) > LEN(C$) THEN 560
			IF MID$( C$, L, LEN(S$) ) <> S$ then 560
			C$ = LEFT$( C$, L-1) + R$ + RIGHT$( C$, LEN(C$)-L-LEN(S$)+1 )
			L = L + LEN(S$)
			GOTO 600									//next L
		
			560:
			IF L + LEN(R$) > LEN(C$) THEN 600			//next L
			IF MID$( C$, L, LEN(R$) ) <> R$ THEN 600	//next L
			
			C$ = LEFT$( C$, L-1) + S$ + RIGHT$( C$, LEN(C$)-L-LEN(R$)+1 )
			L = L + LEN(S$)
			
			NEXT L
		NEXT X
	}
}

------------------------------------------------------------------------------*/



- (NSString *) getReply:(NSString*)Fstr keywordIndex:(NSUInteger)kk keywordLoc:(NSUInteger)tt
{
	// REPLIES
	NSArray *replies = [NSArray arrayWithObjects: @"",
	@"Don't you believe that I can*", 
	@"Perhaps you would like to be able to*", 
	@"You want me to be able to*", 
	@"Perhaps you don't want to*", 
	@"Do you want to be able to*", 
	@"What makes you think I am*", 
	@"Does it please you to believe that I am*", 
	@"Perhaps you would like to be*", 
	@"Do you sometimes wish you were*", 
	@"Don't you really*", 
	@"Why don't you*", 
	@"Do you wish to be able to*", 
	@"Does that trouble you?", 
	@"Tell me more about such feelings.", 
	@"Do you often feel*", 
	@"Do you enjoy feeling*", 
	@"Do you really believe I don't*", 
	@"Perhaps in good time I will*", 
	@"Do you want me to*", 
	@"Do you think you should be able to*", 
	@"Why can't you*", 
	@"Why are you interested in whether or not I am*", 
	@"Would you prefer if I were not*", 
	@"Perhaps in your fantasies I am*", 
	@"How do you know I can't*", 
	@"Have you tried?", 
	@"Perhaps you can now*", 
	@"Did you come to me because you are*", 
	@"How long have you been*", 
	@"Do you believe it is normal to be*", 
	@"Do you enjoy being*", 
	@"We were discussing you — not me.", 
	@"Oh, I *",
	@"You're not really talking about me, are you?", 
	@"What would it mean if you got*", 
	@"Why do you want*", 
	@"Suppose you soon got*", 
	@"What if you never got*", 
	@"I sometimes also want*", 
	@"Why do you ask?", 
	@"Does that question interest you?", 
	@"What answer would please you the most?", 
	@"What do you think?", 
	@"Are such questions on your mind often?", 
	@"What is it you really want to know?", 
	@"Have you asked anyone else?", 
	@"Have you asked such questions before?", 
	@"What else comes to mind when you ask that?", 
	@"Names don't interest me.", 
	@"I don't care about names. Go on..", 
	@"Is that the real reason?", 
	@"Don't any other reasons come to mind?", 
	@"Does that reason explain anything else?", 
	@"What other reason might there be?", 
	@"Please don't apologize.", 
	@"Apologies are not necessary.", 
	@"What feelings do you get when you apologize.", 
	@"Don't be so defensive.", 
	@"What does that dream suggest to you?", 
	@"Do you dream often?", 
	@"What persons appear in your dreams?", 
	@"Are you distrubed by your dreams?",
	@"How do you do.. Please state your problem.", 
	@"You don't seem quite certain.", 
	@"Why the uncertain tone?", 
	@" Can't you be more positive?", 
	@"You aren't sure?", 
	@"Don't you know?", 
	@"Are you saying that just to be negative?", 
	@"You are being a bit negative.", 
	@"Why not?", 
	@"Are you sure?", 
	@"Who no?", 
	@"Why are you concerned about my*", 
	@"What about your own*", 
	@"Can you think of a specific example?", 
	@"When?", 
	@"What are you thinking of?", 
	@"Really, always?", 
	@"Do you really think so?", 
	@"But you are not sure you*", 
	@"Do you doubt you*", 
	@"In what way?", 
	@"What resemblance do you see?", 
	@"What does the similarity suggest to you?", 
	@"What other connections do you see?", 
	@"Could there really be some connection?", 
	@"How?", 
	@"You seem quite positive.", 
	@"Are you sure?", 
	@"I see.", 
	@"I understand.", 
	@"Why do you bring up the topic of friends?", 
	@"Do your friends worry you?", 
	@"Do your friends pick on you?", 
	@"Are you sure you have any friends?", 
	@"Do you impose on your friends?", 
	@"Perhaps your love for friends worries you?", 
	@"Do computers worry you?", 
	@"Are you talking about me in particular?", 
	@"Are you frightened by machines?", 
	@"Why do you mention computers?", 
	@"What do you think computers have to do with your problem?", 
	@"Don't you think computers can help people?", 
	@"What is it about machines that worries you?", 
	@"Say, do you have any problems?",
	@"What does that suggest to you?", 
	@"I see.", 
	@"I'm not sure I understand you fully.", 
	@"Come — elucidate your thoughts.",
	@"Can you elaborate on that?", 
	@"That is quite interesting.", nil];
	
	
	// get reply
	NSString *replyString = [replies objectAtIndex:RR[kk-1]];
	NSLog(@"RR[%d] = %d: %@", kk, RR[kk-1], replyString);
	
	// rotate through REPLIES with Modulo Reset
	RR[kk-1]++;
	if (RR[kk-1] > NN[kk-1]) RR[kk-1] = SS[kk-1];
	
	return replyString;
}



/* --- GET REPLY ---------------------------------------------------------------

// using: R(keyword#), S(keyword#), N(keyword#) > locate correct reply
// pointer for next reply is bumped and reset if too large
// if reply string ends with * it is printed with conjugated string
// else reply string printed alone. previously input string is saved 
// to permit checking of repetitive input. then back to userInput.

	RESTORE : FOR X = 1 TO N1 + N2 : READ Z$ : NEXT X
	FOR X = 1 TO R(K) : READ F$ : NEXT X
	
	R(K) = R(K) + 1
	
	IF R(K) > N(K) THEN R(K) = S(K)
	
	IF RIGHT$( F$, 1 ) <> "*" THEN {
		PRINT F$
		previousInput$ = F$
		GOTO userInput
		EXIT;
		}
	
	ELSE {
		PRINT LEFT$( F$, LEN(F$)-1 ) ; Cstr$
		previousInput$ = F$
		GOTO userInput
		EXIT;
		}

------------------------------------------------------------------------------*/



- (void) speak:(NSString*)myString
{
	AVSpeechSynthesizer *synthesizer = [[AVSpeechSynthesizer alloc] init];
	AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:myString];
	utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"en-gb"];
	[utterance setRate:0.5f];
	[synthesizer speakUtterance: utterance];
	
	/* Subset of Supported Languages:
	ar-SA - Arabic (Saudi Arabia)
	zh-CN - Chinese (China)
	en-GB - English (United Kingdom)
	en-US - English (United States)
	fr-CA - French (Canada)
	fr-FR - French (France)
	de-DE - German (Germany)
	hi-IN - Hindi (India)
	ja-JP - Japanese (Japan)
	pt-BR - Portuguese (Brazil)
	es-MX - Spanish (Mexico)
	es-ES - Spanish (Spain)
	*/

	return;
}


- (void) playSound:(NSInteger) soundIndex
{
	
	//if (gSoundEnabled) {

	SystemSoundID bweep;
	NSString *audioPath1 = [[NSBundle mainBundle] pathForResource:@"sfx02sproing" ofType:@"wav"];
	NSURL *audioPath1URL = [NSURL fileURLWithPath:audioPath1];
	AudioServicesCreateSystemSoundID((__bridge CFURLRef)audioPath1URL, &bweep);
	
	SystemSoundID thinking;
	NSString *audioPath2 = [[NSBundle mainBundle] pathForResource:@"sfx13high" ofType:@"wav"];
	NSURL *audioPath2URL = [NSURL fileURLWithPath:audioPath2];
	AudioServicesCreateSystemSoundID((__bridge CFURLRef)audioPath2URL, &thinking);
	
	
	// PLAY SOUNDS
	if (soundIndex==1) AudioServicesPlaySystemSound (bweep);
	if (soundIndex==2) AudioServicesPlaySystemSound (thinking);
		
	//}

	return;
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}


@end



/*
// allocate an array of NSNumbers
// NSArray *S = [[NSArray alloc] initWithObjects: [NSNumber numberWithInt:1], .., nil];

// convert from NSNumbers to NSIntegers
NSInteger dropSQ = [dropSQobj integerValue];

// convert integer to NSNumber
// NSNumber *dropSQobj = [NSNumber numberWithInteger:fromSquare];

// convert [NSNumber integerValue] returns NSInteger
// convert [NSNumber intValue] returns int

// retrieve string from an array
NSString *fileName = [names objectAtIndex:0];

// MID$ SUBSTRING with RANGE
[@"Some string" length]
[@"abc xyz http://www.abc.com aaa bbb ccc" substringWithRange:NSMakeRange(8, 18)]

// REMOVE QUOTES IN STRING
newString = [myString stringByReplacingOccurrencesOfString:@"\"" withString:@""];

// FIND WORDS IN STRING
NSArray *words = [@"The quick brown fox jumped over the lazy dog" componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet];

// INDEX of STRING
NSUInteger wordLocation = [words indexOfObject:@"brown"];
//test first!!  [array indexOfObject:object] != NSNotFound

NSString *wordInContext = [[words subarrayWithRange:NSMakeRange(brownlocation-2, brownLocation+2)] componentsJoinedByString:@" "];


// FIND WORDS IN STRING
NSArray *words = [@"The quick brown fox jumped over the lazy dog" componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet];
NSUInteger wordIndex = [words indexOfObject:@"brown"];
//[array indexOfObject:object] != NSNotFound

// POSITION OF SUBSTRING in STRING
NSRange range = [inStr rangeOfString:@"substring"];
if (range.location == NSNotFound) NSLog(@"Not Found");
NSUInteger subStrLoc = range.location;

NSUInteger subStrLen = range.length;
NSString *leftStr = [string substringToIndex:range.location];


*/
