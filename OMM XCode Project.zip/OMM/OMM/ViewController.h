//
//  ViewController.h
//  OMM
//
//  Created by John Penner on 07-05-15.
//  Copyright (c) 2015 John Penner. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>
#import <CoreMotion/CoreMotion.h>

@interface ViewController : UIViewController <UITextFieldDelegate>
//@interface ViewController : UIViewController
{
	UILabel *textResponse;
	UILabel *textOutput;
	UITextField *textInput;
	
	
	NSString* inputStr;
	NSString* keywordStr;
	NSString* conjugatedStr;
 
	NSString* Fstr;			// F$ Reply String (also used to save K$ in scanning for keyword)
	NSString* Rstr;			// R$ Used in conjugation process
	NSString* Sstr;			// S$ Used in conjugation process
	NSString* prevInput;			// P$ Previous input string
	NSString* Zstr;			// Z$ Scratch (used for simulating RESTORE NNNN)
	
	NSInteger K;			// K   Keyword Number
	NSInteger Sint, T;			// S,T Used to save K and L when scanning for Keyword
	//NSInteger X, L;			// X,L Scratch where X loops and L scans through Strings
	NSInteger V;			// V   Used for scanning for keyword string
	
	NSInteger N1;
	NSInteger N2;
	NSInteger N3;
	
	//NSArray *S;
	//NSArray *RR;
	//NSArray *N;
	
	
}


@property (nonatomic, strong) IBOutlet UILabel *textResponse;
@property (nonatomic, strong) IBOutlet UILabel *textOutput;
@property (nonatomic, strong) IBOutlet UITextField *textInput;


@property NSString* inputStr;
@property NSString* keywordStr;
@property NSString* conjugatedStr;

@property NSString* Fstr;
@property NSString* Rstr;
@property NSString* Sstr;
@property NSString* prevInput;
@property NSString* Zstr;

@property NSInteger K;
@property NSInteger Sint, T;
//@property NSInteger X, L;
@property NSInteger V;
	
@property NSInteger N1;
@property NSInteger N2;
@property NSInteger N3;

//@property NSArray *S;
//@property NSArray *RR;
//@property NSArray *N;

@end

